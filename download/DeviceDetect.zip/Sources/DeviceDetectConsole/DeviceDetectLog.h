#ifndef _AUTODETECT_LOG_H_
#define _AUTODETECT_LOG_H_

void LogMessage( char *format, ... );

#endif // _AUTODETECT_LOG_H_