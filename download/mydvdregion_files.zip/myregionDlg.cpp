// myregionDlg.cpp : implementation file
//

#include "stdafx.h"
#include "myregion.h"
#include "myregionDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyregionDlg dialog

CMyregionDlg::CMyregionDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMyregionDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMyregionDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMyregionDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyregionDlg)
	DDX_Control(pDX, IDC_EDT_REGION, m_edtRegion);
	DDX_Control(pDX, IDC_EDT_INQUIRY, m_edtInquiry);
	DDX_Control(pDX, IDC_DRIVES_COMBO, m_cbDrives);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMyregionDlg, CDialog)
	//{{AFX_MSG_MAP(CMyregionDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BTN_REFRESH, OnBtnRefresh)
	ON_CBN_SELCHANGE(IDC_DRIVES_COMBO, OnSelchangeDrivesCombo)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyregionDlg message handlers

BOOL CMyregionDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	PopulateDrivesList();

  UpdateDeviceInfos();

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMyregionDlg::PopulateDrivesList()
{
  CString s;

  m_cbDrives.ResetContent();

  DWORD mask = ::GetLogicalDrives();
  int j = 0, i, lastcd = -1;
  for (i=0;i<26;i++)
  {
    if (((1 << i) & mask) == 0)
      continue;
    s.Format(_T("%c:\\"), 'A'+i);
    switch (GetDriveType(s))
    {
    case DRIVE_CDROM:
      s += _T(" (cdrom/dvd)");
      lastcd = i;
      break;
    default:
      s += _T(" (other)");
      break;
    }
    j = m_cbDrives.AddString(s);
    m_cbDrives.SetItemData(j, i);
    if (lastcd != -1)
    {
      m_cbDrives.SetCurSel(j);
      lastcd = -1;
    }
  }
}

void CMyregionDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMyregionDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CMyregionDlg::OnBtnRefresh() 
{
	PopulateDrivesList();
}

bool carry_cdb(HANDLE device, void *cdb, UCHAR cdb_length, void *buffer, DWORD buffer_length, int data_in = SCSI_IOCTL_DATA_IN)
{
  DWORD returned;

  // size of SCSI_PASS_THROUGH + 96 bytes for sense data
  unsigned char cmd[sizeof(SCSI_PASS_THROUGH_DIRECT) + 96] = {0};

  // shortcut to the buffer
  SCSI_PASS_THROUGH_DIRECT *pcmd = (SCSI_PASS_THROUGH_DIRECT *) cmd;

  // Copy the CDB to the SCSI_PASS_THROUGH structure
  memcpy(pcmd->Cdb, cdb, cdb_length);

  pcmd->DataBuffer = buffer;
  pcmd->DataTransferLength = buffer_length;
  pcmd->DataIn = data_in;
  pcmd->CdbLength = cdb_length;
  pcmd->Length = sizeof(SCSI_PASS_THROUGH_DIRECT);
  pcmd->SenseInfoLength = sizeof(cmd) - sizeof(SCSI_PASS_THROUGH_DIRECT);
  pcmd->SenseInfoOffset = sizeof(SCSI_PASS_THROUGH_DIRECT);
  pcmd->TimeOutValue = 6000;

  BOOL bRet = DeviceIoControl(
    device, 
    IOCTL_SCSI_PASS_THROUGH_DIRECT, 
    (LPVOID)&cmd, 
    sizeof(cmd), 
    (LPVOID)&cmd, 
    sizeof(cmd), 
    &returned, 
    NULL);
#ifdef _DEBUG
  DWORD err = ::GetLastError();
  if (err != ERROR_SUCCESS)
  {
    printf("carry_cdb(): last error = %08X\n", err);
  }
#endif
  return bRet ? true : false;
}


void CMyregionDlg::UpdateDeviceInfos()
{
  char devname[20];
  HANDLE device;
  
  sprintf(devname, "\\\\.\\%c:", m_cbDrives.GetItemData(m_cbDrives.GetCurSel()) + 'A');

  device = ::CreateFile(devname, 
    GENERIC_READ | GENERIC_WRITE, 
    FILE_SHARE_READ | FILE_SHARE_WRITE,
    NULL,
    OPEN_EXISTING, 
    0,
    0);

  CString strInquiry = "Could not retrieve Inquiry information!";
  CString strRegion = "Could not retrieve region info!";

  m_edtInquiry.SetWindowText(strInquiry);
  m_edtRegion.SetWindowText(strRegion);

  if (device == (HANDLE)-1)
  {
    MessageBox("Cannot access the drive!");
    return;
  }

  // Get Inquiry information
  do 
  {
    CDB_INQUIRY6 inquiry = {0};
    SCSI_INQUIRY_STD_DATA data = {0};

    inquiry.AllocationLength = sizeof(data);
    inquiry.OperationCode6 = SCSIOP_INQUIRY;

    if (!carry_cdb(device, &inquiry, sizeof(inquiry), &data, sizeof(data)))
      break;

    strInquiry = "";

    CString s;

    char snip[100] = {0};
    int i;
    strncpy(snip, data.vendor_id, i = sizeof(data.vendor_id));
    snip[i] = 0;
    s.Format("Vendor id: %s\r\n", snip);

    strInquiry += s;

    strncpy(snip, data.product_id , i = sizeof(data.product_id));
    snip[i] = 0;
    s.Format("Product id: %s\r\n", snip);

    strInquiry += s;

    strncpy(snip, data.product_revision_level , i = sizeof(data.product_revision_level));
    snip[i] = 0;
    s.Format("Product rev level: %s\r\n", snip);

    strInquiry += s;
  } while (0);

  do
  {
    static char *region_names[] = 
    {
      "United States of America, Canada", // Region 1
      "Europe, including France, Greece, Turkey, Egypt, Arabia, Japan and South Africa", // 2
      "Korea, Thailand, Vietnam, Borneo and Indonesia", // 3
      "Australia and New Zealand, Mexico, the Caribbean, and South America", // 4
      "India, Africa, Russia and former USSR countries", // 5
      "Peoples Republic of China", // 6
      "Unused",
      "Airlines/Cruise Ships",
      "Expansion (often used as region free)"
    };

    static char *region_set[] =
    {
      "No region set", // 0
      "Region set", // 1
      "Drive region is set. Additional restrictions required to make changes", // 2
      "Region set permanently, but may be reset by vendor", // 3

    };

    REPORT_KEY_DATA_RPC_STATE region = {0};
    CDB_REPORT_KEY report = {0};

    report.OperationCode = SCSIOP_REPORT_KEY;
    report.AllocationLength = sizeof(REPORT_KEY_DATA_RPC_STATE);
    report.AGID = 0;
    report.KeyFormat = KEY_FORMAT_RPC_STATE;

    if (!carry_cdb(device, &report, sizeof(report), &region, sizeof(region)))
      break;

    unsigned char region_code = ~region.region_mask;
    int i;

    char *region_name = "No Region Coding";
    for (i=7;i>=0;i--)
    {
      if ( (1 << i) & region_code) 
      {
        region_name = region_names[i];
        break;
      }
    }

    strRegion.Format(
      "Vendor changes: %d\r\n"
      "User changes: %d\r\n"
      "Region name: %s\r\n"
      "Type code: %s\r\n",
      region.nb_vendor_resets,
      region.nb_user_changes,
      region_name,
      region_set[region.type_code]
      );

  } while (0);

  m_edtInquiry.SetWindowText(strInquiry);
  m_edtRegion.SetWindowText(strRegion);

  ::CloseHandle(device);
}

void CMyregionDlg::OnSelchangeDrivesCombo() 
{
  UpdateDeviceInfos();
}
