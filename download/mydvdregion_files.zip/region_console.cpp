#include <stdio.h>
#include <memory.h>
#include "scsi_struct.h"
#include <conio.h>

bool carry_cdb(HANDLE device, void *cdb, UCHAR cdb_length, void *buffer, DWORD buffer_length, int data_in = SCSI_IOCTL_DATA_IN)
{
  DWORD returned;

  // size of SCSI_PASS_THROUGH + 96 bytes for sense data
  unsigned char cmd[sizeof(SCSI_PASS_THROUGH_DIRECT) + 96] = {0};

  // shortcut to the buffer
  SCSI_PASS_THROUGH_DIRECT *pcmd = (SCSI_PASS_THROUGH_DIRECT *) cmd;

  // Copy the CDB to the SCSI_PASS_THROUGH structure
  memcpy(pcmd->Cdb, cdb, cdb_length);

  pcmd->DataBuffer = buffer;
  pcmd->DataTransferLength = buffer_length;
  pcmd->DataIn = data_in;
  pcmd->CdbLength = cdb_length;
  pcmd->Length = sizeof(SCSI_PASS_THROUGH_DIRECT);
  pcmd->SenseInfoLength = sizeof(cmd) - sizeof(SCSI_PASS_THROUGH_DIRECT);
  pcmd->SenseInfoOffset = sizeof(SCSI_PASS_THROUGH_DIRECT);
  pcmd->TimeOutValue = 6000;

  BOOL bRet = DeviceIoControl(
    device, 
    IOCTL_SCSI_PASS_THROUGH_DIRECT, 
    (LPVOID)&cmd, 
    sizeof(cmd), 
    (LPVOID)&cmd, 
    sizeof(cmd), 
    &returned, 
    NULL);
#ifdef _DEBUG
  DWORD err = ::GetLastError();
  if (err != ERROR_SUCCESS)
  {
    printf("carry_cdb(): last error = %08X\n", err);
  }
#endif
  return bRet ? true : false;
}

void print_inquiry_info(HANDLE device)
{
  CDB_INQUIRY6 inquiry = {0};
  SCSI_INQUIRY_STD_DATA data = {0};

  inquiry.AllocationLength = sizeof(data);
  inquiry.OperationCode6 = SCSIOP_INQUIRY;

  if (!carry_cdb(device, &inquiry, sizeof(inquiry), &data, sizeof(data)))
  {
    printf("could not inquire!");
    return;
  }

  printf(
    "Drive info:\n"
    "-----------\n");

  char snip[100] = {0};
  int i;
  strncpy(snip, data.vendor_id, i = sizeof(data.vendor_id));
  snip[i] = 0;
  printf("vendor id: %s\n", snip);

  strncpy(snip, data.product_id , i = sizeof(data.product_id));
  snip[i] = 0;
  printf("product id: %s\n", snip);

  strncpy(snip, data.product_revision_level , i = sizeof(data.product_revision_level));
  snip[i] = 0;
  printf("product rev level: %s\n", snip);
}

void print_region_info(HANDLE device)
{
  static char *region_names[] = 
  {
    "United States of America, Canada", // Region 1
    "Europe, including France, Greece, Turkey, Egypt, Arabia, Japan and South Africa", // 2
    "Korea, Thailand, Vietnam, Borneo and Indonesia", // 3
    "Australia and New Zealand, Mexico, the Caribbean, and South America", // 4
    "India, Africa, Russia and former USSR countries", // 5
    "Peoples Republic of China", // 6
    "Unused",
    "Airlines/Cruise Ships",
    "Expansion (often used as region free)"
  };

  static char *region_set[] =
  {
    "No region set", // 0
    "Region set", // 1
    "Drive region is set. Additional restrictions required to make changes", // 2
    "Region set permanently, but may be reset by vendor", // 3

  };

  REPORT_KEY_DATA_RPC_STATE region = {0};
  CDB_REPORT_KEY report = {0};

  report.OperationCode = SCSIOP_REPORT_KEY;
  report.AllocationLength = sizeof(REPORT_KEY_DATA_RPC_STATE);
  report.AGID = 0;
  report.KeyFormat = KEY_FORMAT_RPC_STATE;

  if (!carry_cdb(device, &report, sizeof(report), &region, sizeof(region)))
  {
    printf("Could not get region info!\n");
    return;
  }

  unsigned char region_code = ~region.region_mask;
  int i;

  char *region_name = "No Region Coding";
  for (i=7;i>=0;i--)
  {
    if ( (1 << i) & region_code) 
    {
      region_name = region_names[i];
      break;
    }
  }

  printf(
    "Region Information:\n"
    "-------------------\n"
    "Vendor changes: %d\n"
    "User changes: %d\n"
    "Region name: %s\n"
    "Type code: %s\n",
    region.nb_vendor_resets,
    region.nb_user_changes,
    region_name,
    region_set[region.type_code]
    );
}

int main(int argc, char *argv[])
{
  HANDLE device;

  char devname[20];
  
  if (argc < 2)
  {
    printf("usage %s drive", argv[0]);
    return -1;
  }

  sprintf(devname, "\\\\.\\%c:", argv[1][0]);

  device = ::CreateFile(devname, 
    GENERIC_READ | GENERIC_WRITE, 
    FILE_SHARE_READ | FILE_SHARE_WRITE,
    NULL,
    OPEN_EXISTING, 
    0,
    0);

  if (device == (HANDLE)-1)
  {
    printf("Cannot open device!\n");
    return -1;
  }

  print_inquiry_info(device);
  printf("\n");
  print_region_info(device);

  ::CloseHandle(device);

  printf("press any key to quit\n");
  getch();

  return 0;
}