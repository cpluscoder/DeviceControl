// myregionDlg.h : header file
//

#if !defined(AFX_MYREGIONDLG_H__E22C92B1_6C37_48D6_821C_3ED5C10873B5__INCLUDED_)
#define AFX_MYREGIONDLG_H__E22C92B1_6C37_48D6_821C_3ED5C10873B5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CMyregionDlg dialog

class CMyregionDlg : public CDialog
{
private:
	void UpdateDeviceInfos();
  void PopulateDrivesList();
// Construction
public:
	CMyregionDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CMyregionDlg)
	enum { IDD = IDD_MYREGION_DIALOG };
	CEdit	m_edtRegion;
	CEdit	m_edtInquiry;
	CComboBox	m_cbDrives;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyregionDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMyregionDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBtnRefresh();
	afx_msg void OnSelchangeDrivesCombo();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYREGIONDLG_H__E22C92B1_6C37_48D6_821C_3ED5C10873B5__INCLUDED_)
